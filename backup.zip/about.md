---
layout: page
title: About Me
permalink: /about/
---
## Ashish Malik | OSCP | CEH

Passionate cyber security professional who has a taste for Offense and Development and a soft corner for Folk Rock and Coffee!

![me](/Walkthrough/images/me.jpg)   

<iframe src="https://embed.spotify.com/?uri=spotify%3Auser%3Aspotify%3Aplaylist%3A34P5EO41t2NwWTDjaj4Sf8" width="300" height="380" frameborder="0" allowtransparency="true"></iframe>